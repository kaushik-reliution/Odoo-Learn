from odoo import api, fields, models, _

class CaseCase(models.Model):
    """
    Task [2994] Case Management for NGO
    """
    _name = 'case.case'
    _rec_name = "reference"

    reference = fields.Char(string='Case Reference', required=True, copy=False, readonly=True, default='New')
    case_start_date = fields.Date(string="Case Start Date", required=True)
    case_end_date = fields.Date(string="Case End Date", required=True)
    case_estimated_amt = fields.Float("Case Estimated Amount", required=True)
    case_achieved_amt = fields.Float("Case Received Amount", compute='_get_received_amount')
    case_remain_amt = fields.Float("Case Remaining Amount")
    contributor_ids = fields.One2many('case.contributor', 'case_id')
    entry_form_ids = fields.One2many('entry.form', 'entry_id')

    @api.model
    def create(self, vals):
        if vals.get('reference', 'New') == 'New':
            vals['reference'] = self.env['ir.sequence'].next_by_code('case.case') or 'New'
        return super(CaseCase, self).create(vals)

    @api.depends('case_achieved_amt')
    def _get_received_amount(self):
        remain_amt = 0
        # final_amt = 0
        for amount in self.contributor_ids:
            remain_amt = remain_amt + amount.contribution_amt

        self.case_achieved_amt = remain_amt
        self.case_remain_amt = self.case_estimated_amt - self.case_achieved_amt

