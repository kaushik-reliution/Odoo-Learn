from odoo import models
import logging

_logger = logging.getLogger("<<<<<<<< Credit Limit Management >>>>>>>>")


class AccountMove(models.Model):
    _inherit = "account.move"

    def total_used_amt(self, partner_id):
        inv_amount = 0
        notes_amt = 0
        inv = self.env['account.move'].search([('move_type', '=', 'out_invoice'), ('partner_id', '=', partner_id.id),
                                               ('payment_state', '=', 'not_paid'), ('state', '=', 'posted')])
        notes = self.env['account.move'].search([('move_type', '=', 'out_refund'), ('partner_id', '=', partner_id.id),
                                                 ('payment_state', '=', 'not_paid'), ('state', '=', 'posted')])

        _logger.info(f"Inv object{inv} credit notes {notes}")
        for record in inv:
            inv_amount = inv_amount + record.amount_residual
        for data in notes:
            notes_amt += data.amount_residual
        total_used_amount = inv_amount - notes_amt
        _logger.info(f"Total Due Amount:------:>> {total_used_amount}")
        return total_used_amount

