from . import res_partner
from . import sale_order
